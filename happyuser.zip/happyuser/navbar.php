<?php 
$categories_query=mysqli_query($db,"select * from category");
 ?>
<!--===== start header area =====-->
		<section class="header-area">
			<div class="container">
				<div class="header-inr">
					<div class="site-logo">
						<a href="index.php">
							<img src="./assets/img/logo.png" alt="" />
						</a>
						<span class="mobile-only menu-open">
							<img src="./assets/img/align-right-solid.svg" alt="" />
						</span>
					</div>
					<div class="site-menu">
						<span class="mobile-only menu-close">
							<img src="./assets/img/cancel.svg" alt="" />
						</span>
						<nav>
							<ul>
								<li><a href="index.php">Home</a></li>
								<!-- <li>
									<a href="blogs.php"
										>Money <img src="./assets/img/angle-down-solid.svg" alt=""
									/></a>
									<ul class="submenu">
										<li><a href="">Submenu</a></li>
										<li><a href="">Submenu</a></li>
										<li><a href="">Submenu</a></li>
										<li><a href="">Submenu</a></li>
									</ul>
								</li> -->
								<!-- <li><a href="blogs.php">Style</a></li> -->
								<!-- <li><a href="blogs.php">Home</a></li> -->
								<?php while($categories_row=mysqli_fetch_array($categories_query)){ ?>
								<li><a href="blogs.php?type=<?php echo $categories_row['name']; ?>"><?php echo $categories_row['name']; ?></a></li>
								<?php } ?>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</section>
		<!--===== completed header area =====-->