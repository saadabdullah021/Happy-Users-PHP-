<?php
session_start();
ob_start();
$db= mysqli_connect('localhost','root','','happyuser_db');
?>
