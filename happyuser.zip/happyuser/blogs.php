<!DOCTYPE html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<title>Blogs | HappyUser</title>
		<meta name="description" content="" />
		<?php include('header.php'); ?>		
	</head>
	<body>
		<?php include('navbar.php'); ?>		
		<!--===== start hero area =====-->
		<section class="hero-area">
			<div class="container">
				<?php 
				if(isset($_GET['type'])){
					$type=$_GET['type'];
					$query=mysqli_query($db,"select * from category where name='$type'");
					$row=mysqli_fetch_array($query);
					$cid=$row['id'];
					$query=mysqli_query($db,"select * from blogs where category='$cid'");
				}else if(isset($_GET['search'])){

					$search=$_GET['search'];
					$query = mysqli_query($db,"SELECT * from blogs where title like '%{$search}%' or content like '%{$search}%' or image like '%{$search}%' or tags like '%{$search}%' or description like '%{$search}%' ");
					$type=$search;
					if($type=="")
						$type="All";
				}
					
				 ?>
				<h1><?=$type?></h1>
				
			</div>
		</section>
		<!-- <div class="sub-header"><div class="taxonomy-description"><blockquote>From the best cities to live in to interesting facts about Canadians, our team provides the facts, laws and trends to help you understand what it’s like to immigrate, live and work in Canada.</blockquote></div></div> -->
		<!--===== completed hero area =====-->
		<!--===== start collation area =====-->
		<section class="collections-area">
			<div class="container">
				
				<div class="collections-items">
				<?php 
				if(mysqli_num_rows($query)!=0){
				while($row=mysqli_fetch_array($query)){
				include('card.php'); 
					} 
				}else{ ?>
					<h3>Oops! No Post Found <span style="color: #B32C2C;">:( </span></h3>
				<?php } ?>
			</div>
		</div>
		</section>
		<!--===== completed collaction area =====-->
		
		<?php include('footer.php'); ?>
	</body>
</html>
