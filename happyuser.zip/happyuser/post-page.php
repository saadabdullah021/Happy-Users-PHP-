<!DOCTYPE html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<?php include('header.php'); ?>
		<title><?php 
		$btitle=$_GET['blog'];
    	$query=mysqli_query($db,"select * from blogs where id='$btitle'");
    	$row=mysqli_fetch_array($query);
    	echo $row['title']." | HappyUser"; ?></title>
    	<meta name="keywords" content="<?php echo $row['tags']; ?>">
    	<meta name="description" content="<?php echo $row['description']; ?>">
	</head>
	<body>
		<?php include('navbar.php'); ?>
		
		<?php 
		$bid=$_GET['blog'];
		$query=mysqli_query($db,"select * from blogs where id='$bid'");
		$row=mysqli_fetch_array($query);
		?>
		<!--===== start collation area =====-->
		<section class="collections-area">
			<div class="container">
			
				<div class="page-inside-hero">
				
				<h1 class="entry-title bcolor" itemprop="headline"><?=$row['title']?></h1>
					<nav class="site-breadcrumbs clr position-under-title"><span><span><a href="index.php">Home</a> » 
						<?php
						 $cid=$row['category'];
                         $qc=mysqli_query($db,"select * from category where id='$cid'");
                         $rc=mysqli_fetch_array($qc);
                        ?>
						<span><a href="blogs.php?type=<?=$rc['name']?>">
						<?=$rc['name']?>
					</a> » <span class="breadcrumb_last" aria-current="page"><?=$row['title']?></span></span></span></span></nav>

				</div>
				
				
				<div class="hero-meta"><p class="post-last-modified">Uploaded: <time class="post-last-modified-td"><?=$row['date']?></time></p></div>
				
				<div class="entry-content" itemprop="text">
					
					<!-- 
					<h2>Contents</h2>
					<ul><li><a href="#documentation" data-type="internal" data-id="#documentation">Reservations &amp; documentation</a></li><li><a href="#packing" data-type="internal" data-id="#packing">Packing</a></li><li><a href="#navigation" data-type="internal" data-id="#navigation">Navigation</a></li><li><a href="#shelter" data-type="internal" data-id="#shelter">Shelter/furniture</a></li><li><a href="#sleeping" data-type="internal" data-id="#sleeping">Sleeping</a></li><li><a href="#clothing" data-type="internal" data-id="#clothing">Clothing &amp; footwear</a></li><li><a href="#health" data-type="internal" data-id="#health">Personal health &amp; hygiene</a></li><li><a href="#cooking" data-type="internal" data-id="#cooking">Cooking</a></li><li><a href="#utility" data-type="internal" data-id="#utility">Utility</a></li><li><a href="#water" data-type="internal" data-id="#water">Water</a></li><li><a href="#fun" data-type="internal" data-id="#fun">Outdoor fun &amp; activities</a></li><li><a href="#baby" data-type="internal" data-id="#baby">Camping with a baby</a></li><li><a href="#kids" data-type="internal" data-id="#kids">Camping with kids</a></li><li><a href="#pets" data-type="internal" data-id="#pets">Camping with pets</a></li><li><a href="#foodideas" data-type="internal" data-id="#foodideas">Food ideas</a></li></ul> -->
					
				
					<img src="upload/<?=$row['image']?>" style="width: 100%;">
					<?=$row['content']?>
					
				</div>
				
				
			</div>
		</section>
		<!--===== completed collaction area =====-->
		<!--===== start promo area =====-->
		<section class="promo-area">
			<div class="container">
				<div class="pm-inr">
					<div class="pm-sing">
						<img src="./assets/img/sing.png" alt="" />
					</div>
					<div class="pm-content">
						<h2>Wants to become a happy user!!</h2>
						<p>Sign up to our newsletter to get the latest product reviews</p>
						<div class="pm-content-input">
							<input type="text" name="" id="" />
							<span>|</span>
						</div>
						<a href="" class="site-btn">subscribe</a>
						<span>*We hate spam as much as you do. </span>
					</div>
				</div>
			</div>
		</section>
		<!--===== completed promo area =====-->
		<?php include('footer.php'); ?>
		
	</body>
</html>



