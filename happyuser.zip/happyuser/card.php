
<div class="coll-itm">
	<a href="post-page.php?blog=<?=$row['id']?>">
		<img src="./upload/<?=$row['image']?>" alt="" />
		<p><?=substr($row['title'],0,30)."..."?></p>
	</a>
</div>
