<!DOCTYPE html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<title>HappyUser | Read what you want</title>
		<meta name="description" content="" />
		<?php include('header.php'); ?>		
	</head>
	<body>
		<?php include('navbar.php'); ?>		
		<!--===== start hero area =====-->
		<section class="hero-area">
		<form method="GET" action="blogs.php">
			<div class="container">
				<h2>Search the best products and services in Canada</h2>
				<div class="hro-field">
					<input type="text" name="search" style="color:black;" placeholder="Search for product" id="" />
					<button>
						<img src="./assets/img/i1.png" alt="" />
					</button>
				</div>
				<button type="submit" class="search-button"><i class="fa fa-search"></i></button>
			</div>
		</form>
		</section>
		<!--===== completed hero area =====-->
		<!--===== start collation area =====-->
		<section class="collections-area">
			<div class="container">
				<div class="sec-title">
					<h2>Recents</h2>
				</div>
				<div class="collections-items">
				<?php 
				$query=mysqli_query($db,"select * from blogs order by id asc limit 6");
				while($row=mysqli_fetch_array($query)){
				include('card.php'); 
				} ?>
				</div>

			</div>
		</section>
		<!--===== completed collaction area =====-->
		
		<!--===== start promo area =====-->
		<section class="promo-area">
			<div class="container">
				<div class="pm-inr">
					<div class="pm-sing">
						<img src="./assets/img/sing.png" alt="" />
					</div>
					<div class="pm-content">
						<h2>Wants to become a happy user!!</h2>
						<p>Sign up to our newsletter to get the latest product reviews</p>
						<div class="pm-content-input">
							<input type="text" name="" id="" />
							<span>|</span>
						</div>
						<a href="" class="site-btn">subscribe</a>
						<span>*We hate spam as much as you do. </span>
					</div>
				</div>
			</div>
		</section>
		<!--===== completed promo area =====-->
		<?php include('footer.php'); ?>
		<!--====== Jquery ======-->
		
	</body>
</html>
