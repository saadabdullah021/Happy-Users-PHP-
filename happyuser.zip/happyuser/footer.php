<!--===== start footer area =====-->
		<footer class="footer-area">
			<div class="container">
				<div class="ftr-inr">
					<div class="ftr-tp-blk">
						<div class="ftr-logo">
							<a href="">
								<img src="./assets/img/l2.png" alt="" />
							</a>
						</div>
						<div class="ftr-scl-lnks">
							<?php 
							$social_query=mysqli_query($db,"select * from social_links where id='1'");
							$social_row=mysqli_fetch_array($social_query);
							 ?>
							<h4>Let’s be friends!</h4>
							<ul>
								<li>
									<a href="<?=$social_row['facebook']?>" target="_blank">
										<img src="./assets/img/facebook-square-brands.svg" alt="" />
									</a>
								</li>
								<li>
									<a href="<?=$social_row['twitter']?>" target="_blank">
										<img src="./assets/img/twitter-brands.svg" alt="" />
									</a>
								</li>
								<li>
									<a href="<?=$social_row['linkedin']?>" target="_blank">
										<img src="./assets/img/linkedin-brands.svg" alt="" />
									</a>
								</li>
								<li>
									<a href="<?=$social_row['pinterest']?>" target="_blank">
										<img src="./assets/img/pinterest-brands.svg" alt="" />
									</a>
								</li>
								<li>
									<a href="<?=$social_row['instagram']?>" target="_blank">
										<img src="./assets/img/instagram-brands.svg" alt="" />
									</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="ftr-btm-blk">
						<p>© Copyright 2020 HappyUser Media Inc.</p>
						<ul class="ftr-lnks">
							<li><a href="">Privacy</a></li>
							<li><a href="">Terms</a></li>
							<li><a href="">Advertising</a></li>
							<li><a href="">Disclosure & Disclaimer</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<!--===== completed footer area =====-->



		<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
		<script>
			$(".menu-open").click(function (e) {
				$(".site-menu").toggleClass("active");
			});
			$(".menu-close").click(function (e) {
				$(".site-menu").removeClass("active");
			});

			if ($("body").innerWidth() < 767) {
				$(".site-menu  li a").click(function (e) {
					$(this).siblings(".submenu").slideToggle("slow");
					$(this)
						.parent()
						.toggleClass("active")
						.siblings()
						.removeClass("active");
					e.preventDefault();
				});
			}

			console.log($("body").innerWidth());
		</script>

		