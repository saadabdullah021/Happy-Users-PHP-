<?php include('db.php'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="manifest" href="site.webmanifest" />
		<!--====== favicon ======-->
		<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico" />
		<!--====== main style ======-->
		<link rel="stylesheet" href="assets/css/style.css" />
		<!--====== responsive ======-->
		<link rel="stylesheet" href="assets/css/responsive.css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">