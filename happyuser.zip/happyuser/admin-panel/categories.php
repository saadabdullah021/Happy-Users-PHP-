<?php include('header.php') ?>
<?php include('config.php');
$msg="";
if (isset($_GET['delete'])) {
  $did=$_GET['delete'];
$query=mysqli_query($db,"delete from category where id='$did'");
if($query){
  $msg="<div class='alert alert-success '>Category Deleted Successfully</div><br>";
}
else{
  $msg="<div class='alert alert-danger'>Error Deleting Category</div><br>";
}
}
 ?>
 <div id="contents">
   <?php include('menu.php') ?>
   <?php include('nav.php') ?>
  <div class="container-fluid">

<div class="col-md-12">

<br>
<h1>Manage Categories</h1>
<br>
<?php echo $msg; ?>
<br>
<a href="add-category.php">
<button class="btn btn-warning">Add Category</button>
</a>
<br>
<br>

<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Category Name</th>
  
  <th>Created</th>
  <th>Edit</th>
  <!-- <th>Delete</th> -->
</tr>
</thead>
<tbody>

  <?php
  $results=mysqli_query($db,"SELECT * FROM category order by id desc");
$a=1;
  while ($data = mysqli_fetch_array($results)  )
{
    ?>
<tr>
<td><?= $a ?></td>

<td><?= $data['name'] ?></td>
<td><?= $data['date'] ?></td>

<td>
  <button class="btn btn-info edit"  onclick="edit(<?= $data['id'] ?>)" > <i class="fa fa-edit"></i>
</td>
<!-- <td><button class="btn btn-danger edit" onclick="deletePost(<?= $data['id'] ?>) "  > <i class="fa fa-trash"></i> </td> -->
</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>
</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
  function deletePost(v){
    location.href='categories.php?delete='+v;
  }
  function edit(v){
    location.href='edit-category.php?edit='+v;
  }
</script>
