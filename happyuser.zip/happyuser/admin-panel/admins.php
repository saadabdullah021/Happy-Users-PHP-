<?php include('header.php') ?>
<?php include('menu.php') ?>
<?php include 'config.php';
$msg="";
if (isset($_GET['make-true'])) {
  // code...
$id= $_GET['make-true'];
$q=mysqli_query($db,"update users set type='2' where userid='$id'");
if($q){
$msg="User Marked As Realtor Successfully";
}
}
if (isset($_GET['make-false'])) {
  $id= $_GET['make-false'];
$q=mysqli_query($db,"update users set type='0' where userid='$id'");
if($q){
  $msg="User Marked As Normal User Successfully";
}
}
?>

    <section id="contents">
      <?php include('nav.php') ?>

<div class="col-md-12">


<br>
<h1> Manage Admins</h1>
<br>
<a href="add-admin.php">
  <button class="btn btn-info">Add Admin</button>
</a>
<br>
<br>
<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Name</th>
  <th>Email</th>
  <th>Password</th>
  <th>Phone</th>
  <th>Pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
  $results=mysqli_query($db,"SELECT * FROM users where type='1' order by userid desc");
$a=1;
  while ($data = mysqli_fetch_array($results))
{
    ?>
<tr>
<td><?= $a ?></td>
<td><?= $data['name'] ?></td>
<td><?= $data['email'] ?></td>
<td><?= $data['password'] ?></td>
<td><?= $data['phone'] ?></td>
<td><img src="<?php if($data['gpic']==1){?>../img/<?= $data['pic'];} else echo $data['pic']; ?>" width="50"></td>
<td>
  <a href="edit-admin.php?edit_admin=<?php echo $data['userid']; ?>" >
  <button class="btn btn-info"> <i class="fa fa-edit"></i> </button>
</a>
</td>
<td>
  <a href="delete.php?del_admin=<?php echo $data['userid']; ?>" onclick="return confirm('Are you sure you want to delete?')">
  <button class="btn btn-danger"> <i class="fa fa-trash"></i> </button>
</a>
</td>


</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
