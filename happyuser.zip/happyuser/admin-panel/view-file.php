<?php include('header.php') ?>
<?php include('config.php');

$fid=$_GET['id'];
$query=mysqli_query($db,"SELECT * from files where id='$fid'");
$row=mysqli_fetch_array($query);
 ?>
 <div id="contents">
   <?php include('menu.php') ?>
   <?php include('nav.php') ?>
  <div class="container-fluid">

<div class="col-md-12">

<br>
<div class="row">  
  <div class="col-md-6"> 
    <h3>File No : <?php echo $row['fileno']; ?></h3>
  </div>
  <div class="col-md-6"> 
    <h3>Created : <?php echo $row['date']; ?></h3>
  </div>
  <div class="col-md-6"> 
    <h3>Name : <?php echo $row['name']; ?></h3>
  </div>
  <div class="col-md-6"> 
    <h3>Phone No : <?php echo $row['phone']; ?></h3>
  </div>
  
  <div class="col-md-12"> 
    <h3 >Detail : </h3>
    <span  class="view-file"><?php echo $row['detail']; ?></span>
  </div>
</div>

<br>
<input type="button" onclick="window.location.href='edit-file.php?edit=<?php echo $fid; ?>'"   name="done" value="Edit File"  class="btn btn-info" >
<input type="button" onclick="window.location.href='files.php'"   value="Go Back"  class="btn btn-warning" >




</div>
</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
  function deletePost(v){
    location.href='files.php?delete='+v;
  }
  function edit(v){
    location.href='edit-file.php?edit='+v;
  }
</script>
