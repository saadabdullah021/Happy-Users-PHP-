<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$msg='';

$id=$_GET['edit'];
$query=mysqli_query($db,"select * from appointments where id='$id'");
$row=mysqli_fetch_array($query);


if(isset($_POST['done'])){
  $fileno=$_POST['fileno'];
  $name=mysqli_real_escape_string($db,$_POST['name']);
  $phone=$_POST['phone'];
  $duration=$_POST['aduration'];
  $adate=$_POST['adate'];
  $time=$_POST['time'];
  $detail=mysqli_real_escape_string($db,$_POST['detail']);

$upload=mysqli_query($db,"update appointments set fileno='$fileno', name='$name', phone= '$phone',  duration= '$duration',appointment_date='$adate',time ='$time',detail='$detail' where id='$id'");

  
  if($upload){
  

    $msg="<br><br><div class='alert alert-success'>Appointment updated successfully</div>"  ;
    // $msg.=mysqli_error($db);

    header('location:appointments.php');
  }
  else {
     echo mysqli_error($db);
  }
    
  

}

 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">


<br>
<h1>Edit Appointment</h1>
<br>
<?php echo $msg; ?>




<h4>Change Status : <button id="pending" onclick="pending(<?php echo $row['id']; ?>)" class="btn btn-danger" style="<?php if($row['status']!="0"){ ?> display: none; <?php } ?>margin-left: 10px;">Pending</button>
<button id="confirm"  onclick="confirm(<?php echo $row['id']; ?>)" class="btn btn-warning" style="<?php if($row['status']!="1"){ ?> display: none; <?php } ?> margin-left: 10px;">Confirm</button>
<button id="complete" class="btn btn-success" style="<?php if($row['status']!="2"){ ?> display: none; <?php } ?> margin-left: 10px;">Complete</button>
</h4>
<br>
<form enctype="multipart/form-data" method="post">

<div class="row">

  

<div class="col-md-6">
  <div class="form-group">

  <label for="">File No</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="fileno" placeholder="XXXXX" value="<?php echo $row['fileno']; ?>" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Name</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo $row['name']; ?>" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Phone</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-mobile "></i>
</div>
<input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo $row['phone']; ?>" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Duration</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-clock "></i>
</div>
<input type="text" class="form-control" name="aduration" placeholder="Duration" value="<?php echo $row['duration']; ?>" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Appointment Date</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="date" class="form-control" name="adate" placeholder="Appointment Date" value="<?php echo $row['appointment_date']; ?>" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Time</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-clock "></i>
</div>
<input type="text" class="form-control" name="time" placeholder="Suitable Time" value="<?php echo $row['time']; ?>" required>
</div>
</div>
</div>



<div class="col-md-12">
  <textarea  name="detail" id="elm1"><?php echo $row['detail']; ?></textarea>
</div>

</div>
<br>
<input type="submit" name="done" value="Update"  class="btn btn-info" >

</div>
</div>
</div>
<br>  
</form>






<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
  function pending(v){
  // alert(v);
  $(document).ready(function () {
   $.ajax({
  url:'change-status.php',
  type:'get',
  data:{val:v},
  success:function(data){
     $('#pending').css('display','none');
     $('#confirm').css('display','inline');

  }
});
               
  });
}
function confirm(v){
  // alert(v);
  $(document).ready(function () {
   $.ajax({
  url:'change-status.php',
  type:'get',
  data:{con:v},
  success:function(data){
     $('#confirm').css('display','none');
     $('#complete').css('display','inline');

  }
});
               
  });
}
</script>