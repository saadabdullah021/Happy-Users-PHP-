<?php include('header.php') ?>
<?php include('menu.php') ?>
<?php include 'config.php';
$msg="";
$type; ?>

    <section id="contents">
      <?php include('nav.php') ?>

<div class="col-md-12">


<br>
<h1> Manage Editor's Form</h1>
<br>
<a href="editor-form.php">
  <button class="btn btn-info">Add Form</button>
</a>
<br>
<br>
<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Name</th>
  <th>Phone</th>
  <th>Adress</th>
  <th>Refered By</th>
  <th>Project</th>
  <th>City</th>
  <th>Info Acquired</th>
  <?php if($type==0){ ?>
  <th>Edit</th>
  <th>Delete</th>
<?php } ?>
</tr>
</thead>
<tbody>

<?php $query=mysqli_query($db,"SELECT * from users where userid='$admin'");
    $data=mysqli_fetch_array($query);
    $type=$data['category'];
 ?>
  <?php
  $results=mysqli_query($db,"SELECT * FROM editor_form  order by id desc");
$a=1;
  while ($data = mysqli_fetch_array($results))
{
    ?>
<tr>
<td><?= $a ?></td>
<td><?= $data['name'] ?></td>
<td><?= $data['phone'] ?></td>
<td><?= $data['adress'] ?></td>
<td><?= $data['refer'] ?></td>

<td><?= $data['project'] ?></td>
<td><?= $data['city'] ?></td>
<td><?= $data['info'] ?></td>
<?php if($type==0){ ?>
<td>
  <a href="edit-form.php?edit_form=<?php echo $data['id']; ?>" >
  <button class="btn btn-info"> <i class="fa fa-edit"></i> </button>
</a>
</td>
<td>
  <a href="delete.php?del_form=<?php echo $data['id']; ?>" onclick="return confirm('Are you sure you want to delete?')">
  <button class="btn btn-danger"> <i class="fa fa-trash"></i> </button>
</a>
</td>

<?php } ?>
</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
