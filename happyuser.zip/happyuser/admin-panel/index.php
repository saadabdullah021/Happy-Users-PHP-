<?php include('header.php') ?>
<?php if (isset($_SESSION['userid']))
{
header('location:home.php');
}
 ?>
 <?php
 $msg="";
 if(isset($_POST['login'])){
   $user=$_POST['name'];
   $pass=$_POST['pass'];
  $result=mysqli_query($db,"SELECT * FROM admin WHERE email='$user' and password='$pass' and type='1' ");
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
//  $active = $row['active'];
  $count = mysqli_num_rows($result);


if($count==1){
  $_SESSION['userid']=$row['id'];
// $_SESSION['name']=$row['username'];
  header('location:home.php');
}
else {
  $msg="Wrong Credentials";
}
 }
  ?>
<body class="back" style="background:url('../assets/img/admin-bg.jpg') no-repeat; background-size:cover">




<!-- =================================Content Section ============================ -->

<div class="container">
<div class="row">

<div class="login ">
  <h1 class="text-center">
    <img src="../assets/img/logo.png" width="200px;">
  </h1>
  <form  method="post">
    <br>
  <div class="form-group">
    <label>Username</label>
  <div class="input-group">
  <div class="input-group-addon ">
  <span class="fa fa-user-circle"></span>
  </div>
  <input type="text" name="name" class="form-control" value="" required placeholder="Enter Your Username">
  </div>
  </div>

  <div class="form-group">
    <label>Password</label>
  <div class="input-group ">
  <div class="input-group-addon icon">
  <span class="fa fa-key"></span>
  </div>
  <input type="password" name="pass" class="form-control" value="" required placeholder="Enter Your Password">
  </div>
  <br>
  <?php
  if($msg!=""){

   ?>
  <p class="alert alert-danger">
  <?php echo $msg ?>
  </p>
  <?php
  }
  ?>
  </div>


  <input type="submit" name="login" class="btn btn-lg center login-btn" value="Login">
  </form>

</div>
</div>
</div>

<footer>



</footer>
</div>
  </body>
</html>
<?php include('footer.php') ?>
