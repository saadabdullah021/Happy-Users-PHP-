<?php include('header.php') ?>
<?php include('config.php'); ?>
<div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">

<?php if (isset($_GET['edit'])) {
  $eid=$_GET['edit'];
  $query= mysqli_query($db,"select * from blogs where id='$eid'");
  $row=mysqli_fetch_array($query);
}
$msg='';
if(isset($_POST['done'])){
  $name=mysqli_real_escape_string($db,$_POST['title']);;
  $cat=mysqli_real_escape_string($db,$_POST['cat']);
  $content=mysqli_real_escape_string($db,$_POST['content']);
  $tags=mysqli_real_escape_string($db,$_POST['tags']);
  $description=mysqli_real_escape_string($db,$_POST['description']);

      $upload=mysqli_query($db,"update blogs set category='$cat',tags='$tags',description='$description', title='$name', content='$content' where id='$eid'");
      if ($upload) {
  // code...
      header('location:blogs.php');
      }

}
if(isset($_POST['update'])){

  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  echo $file_tmp;

  $update=mysqli_query($db,"update blogs set image='$file_name' where id='$eid'");
  if ($update && move_uploaded_file($file_tmp,"../upload/".$file_name)) {
  header('location:blogs.php');
}

}


?>


<br>
<h1>Edit Blog</h1>
<br>
<?php echo $msg; ?>
<form  method="post" enctype="multipart/form-data">
<div class="row"> 
<div class="col-md-6">
  <div class="form-group">

    <br>
    <br>
  <label for="">Blog Image</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-camera"></i>
  </div>
  <input type="file" class="form-control" name="pic"  value="" required>
  </div>
  </div>
  <div class="form-group">
    <input type="submit" name="update" value="Update Image" class="btn btn-info">
  </div>
</div>
</div>
<br>  
</form>
<form enctype="multipart/form-data" method="post">

<div class="row">


  <div class="col-md-6">
  <div class="form-group">

  <label for="">Parent Category</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<select  id="cat" class="form-control" name="cat"  required>

  <?php 
  $cid=$row['category']; 
  $qc=mysqli_query($db,"select * from category where id='$cid'");
  $rc=mysqli_fetch_array($qc);
  ?>


  <option value="<?php echo $rc['id']; ?>"><?php echo $rc['name']; ?></option>


  <?php 
    $category=mysqli_query($db,"select * from category");
    while ($category_row=mysqli_fetch_array($category)) { ?>

   <option value="<?php echo $category_row['id']; ?>"><?php echo $category_row['name']; ?></option>
 <?php  } ?>
</select>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Blog Title</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="title" placeholder="Enter Blog Title" value="<?php echo $row['title'] ?>" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Blog Tags</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="tags" placeholder="Enter Blog Tags" value="<?php echo $row['tags'] ?>" required>
</div>
</div>
</div>

<div class="col-md-12">
  <div class="form-group">

  <label for="">Meta description</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-edit"></i>
  </div>
  <input type="text" class="form-control" name="description" placeholder="Enter Meta description" value="<?php echo $row['description']; ?>" required>
  </div>
  </div>
</div>


<div class="col-md-12">
  <textarea name="content" id="elm1"  ><?php echo $row['content'] ?></textarea>
</div>
</div>
<br>
<input type="submit" name="done" value="Update Blog"  class="btn btn-info" >

</form>
<br>  
</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
$(function() {
    $('#elm1').ckeditor({
        toolbar: 'Full',
        enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
});
</script>