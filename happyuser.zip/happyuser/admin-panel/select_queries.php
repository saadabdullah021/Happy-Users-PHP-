
<?php include('dbcon.php'); ?>

<?php  
$type=$_GET['type'];
$val=$_GET['value'];



?>


<?php if($type=="category"){ ?>

  <option value="">Please Select Parent Sub-Category</option>
  <?php  $sub_category=mysqli_query($db,"select * from subcategory where parent_cat='$val'");

   while ($sub_category_row=mysqli_fetch_array($sub_category)) {?>
              <option><?php echo $sub_category_row['name']; ?></option>
               <?php } ?>



 <?php }  else if($type=="edit_category"){  ?>

<div class="col-md-6">
  <div class="form-group">
  <label for="">Parent Sub-Category</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<select  class="form-control" id="sub-cat" name="sub-cat"  required>
  <option value="">Please Select Parent Category First</option>
  
  <?php  $sub_category=mysqli_query($db,"select * from subcategory where parent_cat='$val'");

   while ($sub_category_row=mysqli_fetch_array($sub_category)) {?>
              <option><?php echo $sub_category_row['name']; ?></option>
               <?php } ?>

</select>
</div>
</div>
</div>

 <?php } else if($type=="product"){ ?>

  <option value="">Please Select Parent Sub-Sub-Category</option>
  
    <?php 
    $sub_sub_category=mysqli_query($db,"select * from subsubcategory where parent_subcat='$val'");
    while ($sub_sub_category_row=mysqli_fetch_array($sub_sub_category)) {
   ?>
   <option><?php echo $sub_sub_category_row['name']; ?></option>
 <?php } ?> 

<?php } ?>


