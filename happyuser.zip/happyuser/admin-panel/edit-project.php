<?php include('header.php') ?>
<?php include('menu.php') ?>
<?php include 'config.php';
$check="";
$ok="";
$msg="";
if (isset($_GET['pid'])) {
$id=$_GET['pid'];
$query=mysqli_query($db,"select * from project where pid='$id'");
$pro=mysqli_fetch_array($query);
}
if(isset($_POST['submit']))
{
$Location=$_POST['Location'];
$address=$_POST['address'];
$price1=$_POST['price1'];
$price2=$_POST['price2'];
$type=$_POST['property-type'];
$developer=$_POST['developer'];
$desc=mysqli_real_escape_string($db,$_POST['description']);
$extension=array("jpeg","jpg","png","gif");
$check='';
$msg='';
$n="";$ok='';
$toid="";
$sql=mysqli_query($db,"update project set Location='$Location',address='$address',price_from='$price1',price_to='$price2',type='$type',dev_name='$developer',description='$desc' where pid='$id'");



foreach($_FILES["upload_imgs"]["tmp_name"] as $key=>$tmp_name) {
$file_name=$_FILES["upload_imgs"]["name"][$key];
$file_tmp=$_FILES["upload_imgs"]["tmp_name"][$key];
$toid=$_GET['pid'];
    $img_name=time().uniqid(rand());
$extension=array("jpeg","jpg","png","gif");
$ext=pathinfo($file_name,PATHINFO_EXTENSION);
    $img_name=time().uniqid(rand()).".".$ext;
if(in_array($ext,$extension)) {
$upload=mysqli_query($db,"insert into project_img(images,pid)values('$img_name','$toid')");
if($upload){
move_uploaded_file($file_tmp=$_FILES["upload_imgs"]["tmp_name"][$key],"../img/projects/".$img_name);
$ok='Project has been updated';
}

}}

if(isset($_POST['backup']))
{
$query=mysqli_query($db,"UPDATE project set backup='1' where pid='$id'");
}
if(isset($_POST['Sewerage']))
{
$query=mysqli_query($db,"UPDATE project set sewerage='1' where pid='$id'");
}
if(isset($_POST['Electricity']))
{
$query=mysqli_query($db,"UPDATE project set electricity='1' where pid='$id'");
}
if(isset($_POST['Water']))
{
$query=mysqli_query($db,"UPDATE project set water='1' where pid='$id'");
}
if(isset($_POST['Gas']))
{
$query=mysqli_query($db,"UPDATE project set gas='1' where pid='$id'");
}
if(isset($_POST['Road']))
{
$query=mysqli_query($db,"UPDATE project set road='1' where pid='$id'");
}
if(isset($_POST['Mosque']))
{
$query=mysqli_query($db,"UPDATE project set mosque='1' where pid='$id'");
}
if(isset($_POST['Schools']))
{
$query=mysqli_query($db,"UPDATE project set school='1' where pid='$id'");
}

if(isset($_POST['Hospitals']))
{
$query=mysqli_query($db,"UPDATE project set hospital='1' where pid='$id'");
}

if(isset($_POST['Malls']))
{
$query=mysqli_query($db,"UPDATE project set mall='1' where pid='$id'");
}

if(isset($_POST['Resturants']))
{
$query=mysqli_query($db,"UPDATE project set resturant='1' where pid='$id'");
}

if(isset($_POST['Transport']))
{
$query=mysqli_query($db,"UPDATE project set transport='1' where pid='$id'");
}
if($sql){

header('location:projects.php');
}
}
?>


<section id="contents">
  <?php
include('nav.php')
?>


<div class="container">
<form method="post" enctype="multipart/form-data" onsubmit="" id="contact_form">
<h1>Edit Project</h1>

<!-- Form Name -->
<?php
if($msg!=""){
  ?>
<div class="alert alert-danger">
  <?php echo $msg ?>
</div>
  <?php
}
if ($ok!="") {
  // code...
  ?>
  <div class="alert alert-success">
    <?php echo $ok?>
  </div>

  <?php
}
 ?>

<br>
<div class="panel panel-default">
<div class="panel-heading"><h2>Overview</h2></div>
<br>

<!-- Text input-->

<div class="panel-body text-primary">
<div class="row">

<div class="col-md-4">
<label class="control-label">Select City</label>
<div class="form-group">
<select class="form-control"name="Location" id="selectid" >
<?php
$ic=mysqli_query($db,"select * from cities");
while ($city=mysqli_fetch_array($ic)) {
  // code...
  if($pro['Location']==$city['cid']){
    ?>
    <option value="<?php echo $city['cid'] ?>" selected><?php echo $city['name'] ?></option>

    <?php
  }else{

  ?>
  <option value="<?php echo $city['cid'] ?>" ><?php echo $city['name'] ?></option>
  <?php
}
}
 ?>
</select>
<span id="errorcity" class="error" ></span>

</div>
</div>



<div class="col-md-4">
<label class=" control-label">Title</label>
<div class="form-group">
<input name="address" placeholder="Enter Title" value="<?php echo $pro['address'] ?>" class="form-control" type="text" id="address">
<span id="address_error" class="error" ></span>
</div>


</div>





<!-- Price -->
<div class="col-md-2">
<label class=" control-label">Price From</label>
<div class="form-group">

<input name="price1" placeholder="0.00" value="<?php echo $pro['price_from'] ?>" class="form-control" type="text" id="price1">

<span id="price1_error" class="error" ></span>
</div>
</div>

<div class="col-md-2 ">
<div class="form-group">

<label class="control-label">Price To</label>
<input name="price2" placeholder="0.00" value="<?php echo $pro['price_to'] ?>" class="form-control" type="text" id="price2">

<span id="price2_error" class="error" ></span>
</div>

</div>
</div>




<!-- select property -->
<div class="row">


<div class="col-md-4">

<label class=" control-label">Setect Property type</label>
<div class="form-group">
<select class="form-control"name="property-type" id="typeid">
  <?php
    if($pro['type']==1){
      ?>
    <option value="1" selected>Homes</option>
    <option value="2">Residential Plot </option>
    <option value="3">Commercial Plot </option>
    <option value="4">Agriculture Land </option>
    <option value="5">Shops</option>
    <option value="6">Office</option>
    <option value="7">Building</option>
    <option value="8">Commercial</option>

      <?php
    }
   if($pro['type']==2){
  ?>
  <option value="1">Homes</option>
  <option value="2" selected>Residential Plot </option>
  <option value="3">Commercial Plot </option>
  <option value="4">Agriculture Land </option>
  <option value="5">Shops</option>
  <option value="6">Office</option>
  <option value="7">Building</option>
  <option value="8">Commercial</option>

  <?php  }
     if($pro['type']==3){
  ?>
  <option value="1">Homes</option>
  <option value="2">Residential Plot </option>
  <option value="3" selected>Commercial Plot </option>
  <option value="4">Agriculture Land </option>
  <option value="5" >Shops</option>
  <option value="6">Office</option>
  <option value="7">Building</option>
  <option value="8">Commercial</option>

  <?php  }

     if($pro['type']==4){
  ?>
  <option value="1">Homes</option>
  <option value="2">Residential Plot </option>
  <option value="3">Commercial Plot </option>
  <option value="4" selected>Agriculture Land </option>
  <option value="5">Shops</option>
  <option value="6">Office</option>
  <option value="7">Building</option>
  <option value="8">Commercial</option>
  <?php  }
     if($pro['type']==5){
  ?>
  <option value="1">Homes</option>
  <option value="2">Residential Plot </option>
  <option value="3">Commercial Plot </option>
  <option value="4">Agriculture Land </option>
  <option value="5"selected>Shops</option>
  <option value="6">Office</option>
  <option value="7">Building</option>
  <option value="8">Commercial</option>
  <?php  }
   if($pro['type']==6){
    ?>

    <option value="1">Homes</option>
    <option value="2">Residential Plot </option>
    <option value="3">Commercial Plot </option>
    <option value="4">Agriculture Land </option>
    <option value="5">Shops</option>
    <option value="6"selected>Office</option>
    <option value="7">Building</option>
    <option value="8">Commercial</option>
  <?php
  }
  ?><?php
     if($pro['type']==7){
       ?>
  <option value="1">Homes</option>
  <option value="2">Residential Plot </option>
  <option value="3">Commercial Plot </option>
  <option value="4">Agriculture Land </option>
  <option value="5">Shops</option>
  <option value="6">Office</option>
  <option value="7"selected>Building</option>
  <option value="8">Commercial</option>

  <?php
  }
  ?>

  <?php
     if($pro['type']==8){
  ?>
  <option value="1">Homes</option>
  <option value="2">Residential Plot </option>
  <option value="3">Commercial Plot </option>
  <option value="4">Agriculture Land </option>
  <option value="5">Shops</option>
  <option value="6">Office</option>
  <option value="7">Building</option>
  <option value="8" selected>Commercial</option>
  <?php  }
    ?>
</select>
<span id="typeerror" class="error" ></span>

</div>
</div>


<!-- Developer -->

<div class="col-md-4 ">
<label class=" control-label">Developer Name</label>
<div class="form-group">

<input style="padding-left: 10px" name="developer" value="<?php echo $pro['dev_name'] ?>" placeholder="Name" class="form-control" type="text" id="developer">
<span id="developer_error" class="error" ></span>
</div>
</div>


</div><!-- end of row -->


</div>
</div>
<br>

<!-- Project features -->
<br>




<div class="panel panel-default">
<div class="panel-heading"><h2>Project Features</h2></div>
<div class="panel-body text-primary"><h3>MAIN FEATURES</h3>

<div class="row">
<div class="col-md-4">

<!-- checkbox -->
<label for="features[]">

<input type="checkbox" name="Backup" value="1" <?php if($pro['backup']==1){echo "checked";} ?>>&nbsp;
Electricity Backup
</label>


</div>
</div><!-- end of row -->



<div ><h3>PLOT FEATURES</h3></div>
<div class="row">


<div class="col-md-4">
<input style="" type="checkbox" value="1" name="Sewerage" <?php if($pro['sewerage']==1){echo "checked";} ?>>&nbsp; <label>Sewerage</label>

</div>


<div class="col-md-4">
<input style="" value="1" type="checkbox" name="Electricity" <?php if($pro['electricity']==1){echo "checked";} ?>>&nbsp; <label>Electricity</label>

</div>



<div class="col-md-4">
<input style="" type="checkbox" value="1" name="Water" <?php if($pro['water']==1){echo "checked";} ?>>&nbsp; <label>Water Supply</label>

</div>

</div>

<div class="row">

<div class="col-md-4">
<input style="" type="checkbox" value="1" name="Gas" <?php if($pro['gas']==1){echo "checked";} ?>>&nbsp; <label>Sui Gas</label>


</div>


<div class="col-md-4">
<input style=";" type="checkbox" value="1" name="Road" <?php if($pro['road']==1){echo "checked";} ?>>&nbsp; <label>Accessible by Road</label>

</div>
</div><!-- end of row -->

<div ><h3>COMMUNITY FEATURES</h3></div>

<div class="row">
<div class="col-md-12">
<input style="" value="1" type="checkbox" name="Mosque" <?php if($pro['mosque']==1){echo "checked";} ?>>&nbsp; <label>Mosque</label>

</div>
</div><!-- end of row -->


<div><h3>NEARBY LOCATIONS AND OTHER FACILITES</h3></div>
<div class="row">

<div class="col-md-4">
<input style="" value="1" type="checkbox" name="Schools" <?php if($pro['school']==1){echo "checked";} ?>>&nbsp; <label> Nearby Schools</label>

</div>


<div class="col-md-4">
<input type="checkbox" value="1" name="Hospitals" style="" <?php if($pro['hospital']==1){echo "checked";} ?>>&nbsp; <label>Nearby Hospitals</label>
</div>


<div class="col-md-4">
<input style=";" value="1" type="checkbox" name="Malls" <?php if($pro['mall']==1){echo "checked";} ?>>&nbsp; <label>Nearby Shopping Malls</label>


</div>
</div><!-- end of row -->



<div class="row">

<div class="col-md-4">
<input style=";" value="1" type="checkbox" name="Resturants" <?php if($pro['resturant']==1){echo "checked";} ?>>&nbsp; <label>Nearby Resturants</label>


</div>




<div class="col-md-4">
<input style=";" value="1" type="checkbox" name="Transport" <?php if($pro['transport']==1){echo "checked";} ?>>&nbsp; <label>Nearby Public Transport Services</label>
</div>
</div><!-- end of row -->
<br><br>




<!-- textbox -->


<div class="row">
<div class="col-md-12 form-group">
<label>Other Descriptions</label>
<textarea class="form-control ta" name="description" id="elm1" cols="139" placeholder="Other Descriptions"><?php echo $pro['description'] ?></textarea>
</div>
</div>

</div>

<?php

$q=mysqli_query($db,"SELECT * from project_img where pid='$id'");
?>

<label>Project images</label>
<div class="row">
<?php
while($data=mysqli_fetch_array($q)){
?>
<div class="col-md-3">
     <button class="btn remove" id="remove" style="padding:0px;outline:none;border:none;margin-top:1px;position:absolute;"><i class="fas fa-window-close" style="font-size:22px;"></i></button>
    <img class="img-responsive" src="../img/projects/<?php echo $data['images'] ?>">
    <input type="hidden" value="<?php echo $data['id']  ?>" id="iid">
   
</div>

<?php
}
?>
</div>




<div class="row">

<div class="container">

   
<div class="row">
<div class="col-md-12" style="margin-top:50px">
    
   <label>Update images</label> 
   <br>
<label for="upload_imgs" class="btn btn-primary">Select Your Images +</label>
<input class="show-for-sr hidden" type="file" id="upload_imgs" name="upload_imgs[]" multiple/ >
<span class=" alert-info btn-sm"><medium> <i class="fa fa-exclamation-triangle"></i> Press CTRL to select multiple images at once</medium></span>
<br> <span style="padding: 15px" class="error" id="imgs"> Please Attach atleast one image </span>

<br>
<div class="grid-x grid-padding-x">
<div class="small-10 small-offset-1 medium-8 medium-offset-2 cell">
<p>
<div class="quote-imgs-thumbs quote-imgs-thumbs--hidden" id="img_preview" aria-live="polite"></div>
</p>

</div>
</div>
<input type="submit" name="submit" value="Submit" class="btn btn-primary">

</div>
</div>


</div>
</div>

</form>

<!-- Button -->
<!--<div class="form-group">-->
<!--<input class="btn btn-primary" type="submit" name="submit" value="Submit">-->
<!--</div>-->
<!--</div>-->
</div>
<!-- end of panel -->

</div>
</div><!-- /.container -->


<?php include 'footer.php'; ?>



<!-- Script validation -->


<script type="text/javascript">

function validation(){
var isok=true;
var location_f=document.getElementById('selectid').value;
var address_f=document.getElementById('address').value;
var price1_f=document.getElementById('price1').value;
var price2_f=document.getElementById('price2').value;
var developer_f=document.getElementById('developer').value;

if(location_f=="")
{
$('#errorcity').fadeIn();
$('#selectid').css("border-color","red")
setTimeout(function(){
$('#errorcity').fadeOut();
$('#selectid').css("border-color","#ccc")
},3500);
document.getElementById('errorcity').innerHTML=" ** Please Enter Address";
isok=false;
}
if($('#typeid').val()=="")
{
$('#typeerror').fadeIn();
$('#typeid').css("border-color","red")
setTimeout(function(){
$('#typeerror').fadeOut();
$('#typeid').css("border-color","#ccc")
},3500);
document.getElementById('typeerror').innerHTML=" ** Please Enter Address";
isok=false;
}

if(address_f=="")
{
$('#address_error').fadeIn();
$('#address').css("border-color","red")
setTimeout(function(){
$('#address_error').fadeOut();
$('#address').css("border-color","#ccc")
},3500);
document.getElementById('address_error').innerHTML=" ** Please Enter Address";
isok=false;
}
if(price1_f=="")
{
$('#price1_error').fadeIn();
$('#price1').css("border-color","red")
setTimeout(function(){
$('#price1_error').fadeOut();
$('#price1').css("border-color","#ccc")
},3500);
document.getElementById('price1_error').innerHTML=" ** Please Enter price";
isok=false;
}
if(price2_f=="")
{
$('#price2_error').fadeIn();
$('#price2').css("border-color","red")
setTimeout(function(){
$('#price2_error').fadeOut();
$('#price2').css("border-color","#ccc")
},3500);
document.getElementById('price2_error').innerHTML=" ** Please Enter price";
isok=false;
}
if(developer_f=="")
{
$('#developer_error').fadeIn();
$('#developer').css("border-color","red")
setTimeout(function(){
$('#developer_error').fadeOut();
$('#developer').css("border-color","#ccc")
},3500);
document.getElementById('developer_error').innerHTML=" ** Please Enter Developer Name";
isok=false;
}
if($('#upload_imgs').val()=="")
{
$('#imgs').fadeIn();
setTimeout(function(){
$('#imgs').fadeOut();
// $('#developer').css("border-color","#ccc")
},3500);
document.getElementById('developer_error').innerHTML=" ** Please Enter Developer Name";
isok=false;
}
return isok;

}




var imgUpload = document.getElementById('upload_imgs')
, imgPreview = document.getElementById('img_preview')
, imgUploadForm = document.getElementById('contact-form')
, totalFiles
, previewTitle
, previewTitleText
, img;

imgUpload.addEventListener('change', previewImgs, false);


function previewImgs(event) {
totalFiles = imgUpload.files.length;

if(!!totalFiles) {
imgPreview.classList.remove('quote-imgs-thumbs--hidden');
previewTitle = document.createElement('p');
previewTitle.style.fontWeight = 'bold';
previewTitleText = document.createTextNode(totalFiles + ' Total Images Selected');
previewTitle.appendChild(previewTitleText);
imgPreview.appendChild(previewTitle);
}

for(var i = 0; i < totalFiles; i++) {
img = document.createElement('img');
img.src = URL.createObjectURL(event.target.files[i]);
img.classList.add('img-preview-thumb');
imgPreview.appendChild(img);
}
}
</script>
<script>
$(document).ready(function(){
    $('.remove').click(function(){
        var id=$('#iid').val();
        $.ajax({
            type:'get',
            url:'del_project_img.php',
            data:{id:id,pid:<?php echo $id ?>},
            success:function(data){

            }
        });
    });
});
</script>
</section>
