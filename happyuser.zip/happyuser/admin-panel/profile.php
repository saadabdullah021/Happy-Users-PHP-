<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$q=mysqli_query($db,"select * from admin where id='$user'");
$v=mysqli_fetch_array($q);
 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <br>
  <div class="container" style="color:black">
  <div class="row">
    <div class="col-md-10"> 
    <div class="panel-group">
      <div class="panel panel-default">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-6">
          <h3>Your Profile</h3>
           </div>
            <div class="col-md-6 text-right">
          <div class="row">
            <p style="padding-right:12px;padding-top:23px;vertical-align: middle">
              <a href="edit-profile.php">Edit Profile</a> |
            <a href="edit-password.php" title="">Edit Password</a> |
          <a href="logout.php">Logout <i class="fa fa-sign-out-alt"></i> </a>
            </p>
            </div>
          </div>
          </div>
           </div>

        <div class="panel-body">
  <div class="col-md-4">

      <?php if ($v['image']!=""){ ?>
    <img src="../upload/<?php echo $v['image'] ?>" style="height:200px;width:200px;border-radius:50%;border:3px solid white;display:block;margin:0 auto;border:3px solid black;
    " alt="">
    <?php
    }
    else{

    ?>
    <br>  
    <img src="../images/person-icon-8.png" style="height:200px;width:200px;border-radius:50%;border:3px solid white;display:block;margin:0 auto;border:3px solid black;
    " alt="">



    <?php
    }

    ?>
  </div>
  <div class="col-md-8">
    <br><br>
  
  <div class="row">
    <div class="col-md-3">
      <label style="font-size:17px" style="margin-top:5px;" for="name">Name</label>
    </div>
    <div class="col-md-4">
      <label><?php echo $v['name'] ?></label>
    </div>
  </div>
  <div class="row"> 
    <div class="col-md-3">
      <label style="font-size:17px" style="margin-top:5px;" for="email">Email</label>
    </div>
    <div class="col-md-4">
      <label><?php echo $v['email'] ?></label>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-3">
      <label style="font-size:17px" style="margin-top:5px;" for="email">Password</label>
    </div>
    <div class="col-md-4">
      <label style="font-size:17px" style="margin-top:5px;" for="email"><?php echo "********" ?></label>
    </div>
  </div>

  </div>
  <div class="clearfix">

  </div>
  </div>
  </div>
  </div>
  </div>
</div>
        </div>
      </div>
</section>


<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
