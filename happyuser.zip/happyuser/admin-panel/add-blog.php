<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$msg='';

if(isset($_POST['done'])){

  $name=mysqli_real_escape_string($db,$_POST['title']);
  $cat=mysqli_real_escape_string($db,$_POST['cat']);
  $content=mysqli_real_escape_string($db,$_POST['content']);
  $tags=mysqli_real_escape_string($db,$_POST['tags']);
  $description=mysqli_real_escape_string($db,$_POST['description']);
  $date=date('d M Y');
  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  $upload=mysqli_query($db,"insert into blogs(category,title,content,tags,description,image,date) values('$cat','$name','$content','$tags','$description','$file_name','$date')");
  if(move_uploaded_file($file_tmp,"../upload/".$file_name)){
    $msg="<br><br><div class='alert alert-success'>Post Uploaded successfully</div>"  ;
    // $msg.=mysqli_error($db);
    header('location:blogs.php');
  }

}

 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">


<br>
<h1>ADD BLOG</h1>
<br>
<?php echo $msg; ?>
<form enctype="multipart/form-data" method="post">

<div class="row">

  <div class="col-md-6">
  <div class="form-group">

  <label for="">Select Category</label>
  <div class="input-group">
    <div class="input-group-addon icon">
      <i class="fa fa-edit "></i>
      </div>
       <select  id="cat" class="form-control" name="cat"  required>
        <option value="">Please Select Parent Category</option>
        <?php 
          $category=mysqli_query($db,"select * from category order by id desc");
          while ($category_row=mysqli_fetch_array($category)) {
         ?>
         <option value="<?php echo $category_row['id']; ?>"><?php echo $category_row['name']; ?></option>
       <?php } ?>
      </select>
</div>
</div>
</div>

<div class="col-md-6"></div>
<div class="col-md-6">
  <div class="form-group">

  <label for="">Blog Title</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="title" placeholder="Enter Blog Title" value="" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Add Tags (cute dogs, human friendly etc)</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="tags" placeholder="Enter Blog Tags" value="" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Blog Image</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-camera"></i>
  </div>
  <input type="file" class="form-control" name="pic" value="" required>
  </div>
  </div>
</div>

<div class="col-md-12">
  <div class="form-group">

  <label for="">Meta description</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-edit"></i>
  </div>
  <input type="text" class="form-control" name="description" placeholder="Enter Meta description" value="" required>
  </div>
  </div>
</div>

<div class="col-md-12">
  <textarea name="content" id="elm1"></textarea>
</div>
</div>
<br>
<input type="submit" name="done" value="Upload Blog"  class="btn btn-info" >

</div>
</div>
</div>
<br>  
</form>
<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
