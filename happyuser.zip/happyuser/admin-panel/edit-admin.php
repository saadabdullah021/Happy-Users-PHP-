<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
if (isset($_GET['edit_admin'])) {
  $madmin=$_GET['edit_admin'];
}
if(isset($_POST['done'])){
  $name=$_POST['name'];
  $email=$_POST['username'];
  $pass=$_POST['password'];
  $phone=$_POST['phone'];
  $upload=mysqli_query($db,"UPDATE users SET name='$name',email='$email', password='$pass' ,phone='$phone' WHERE userid='$madmin' ");
  if($upload){
  header('location:admins.php');
}
}
if (isset($_POST['update'])) {
  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  $q=mysqli_query($db,"update users set pic='$file_name' where userid='$madmin'");
  if($q){
  move_uploaded_file($file_tmp,"../img/".$file_name);
  header('location:admins.php');
}

}
 ?>
 <?php include('menu.php') ?>
 <div id="contents">
   <?php include('nav.php') ?>
<div class="container-fluid">
<?php
$results=mysqli_query($db,"SELECT * FROM users where userid='$madmin'");
$data=mysqli_fetch_array($results);
 ?>
 <div class="col-md-12">

 <br>
 <h1> Add New Admin</h1>
 <br>
 <form method="post" enctype="multipart/form-data" name="frm">

   <div class="col-md-4 ">

     <div style="color:red" id="dan">
   </div>
   <div class="form-group">
     <label>Name</label>
   <div class="input-group">
   <div class="input-group-addon icon">
   <span class="fa fa-user-o"></span>
   </div>
   <input type="text" name="name" class="form-control" value="<?php echo $data['name'] ?>" placeholder="Enter Name" required>
   </div>
   </div>

 <div class="form-group">
   <label>Email</label>
 <div class="input-group">
 <div class="input-group-addon icon">
 <span class="fa fa-user-o"></span>
 </div>
 <input type="email" name="username" class="form-control" value="<?php echo $data['email'] ?>" placeholder="Enter Email" required>
 </div>
 </div>

 <div class="form-group">
   <label>password</label>
 <div class="input-group">
 <div class="input-group-addon icon">
 <span class="fa fa-lock"></span>
 </div>
 <input type="text" name="password" class="form-control" placeholder="Enter Password"  value="<?php echo $data['password'] ?>"required>
 </div>

 </div>
 <div class="form-group">
   <label>Phone</label>
 <div class="input-group">
 <div class="input-group-addon icon">
 <span class="fa fa-envelope"></span>
 </div>
 <input type="text" name="phone" class="form-control" placeholder="Enter Phone" value="<?php echo $data['phone'] ?>"  required>
 </div>
 </div>



 <div class="form-group">
 <br>
   <input type="submit" name="done" value="Save Changes" class="btn-info btn" onclick="valid()">
 </div>
 </form>
 <br>


 <br>
<h2>Edit Image</h2>
<form enctype="multipart/form-data" method="post">
  <label>Select Your Image</label>
  <div class="input-group">

  <input type="file" name="pic" class="input hidden" id="pic" value="" required>
  </div>
  <span class="btn-warning  btn-sm  " > <label for="pic" >Choose Image</label> </span>
  <br><br>
<input type="submit" name="update" value="Update Image" class="btn btn-info">
</form>

 <p class="text-center">
 <a href="admin.php" class="back"> <i class="fa fa-arrow-left"></i> Go Back</a>
 </p>
 <br>
 <br>

 </div>
 </div>

</div>
  </div>


</div>
<script type="text/javascript">
  function valid(){
    var c=document.frm;
    if(c.username.value==''){
      document.getElementById('dan').innerHTML="Username is Required";
      return false;
    }
    else if(c.password.value==''){
      document.getElementById('dan').innerHTML="Password is Required";
      return false;

    }
  else if(c.pic.value==''){
      document.getElementById('dan').innerHTML="Image is Required";
      return false;
    }
    return true;
  }
</script>

</div>

<br>

</div>


</div>



<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
