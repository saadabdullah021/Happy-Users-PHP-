<script src='js/jquery-latest.js'></script>
<script src="js/bootstrap.min.js" ></script>
<script src="js/Chart.bundle.js"></script>
<script src='js/main.js'></script>
<script type="text/javascript" src="./js/query.dataTables.min.js"></script>
<script type="text/javascript" src="./js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="./js/dataTables.fixedHeader.min.js"></script>
<script type="text/javascript" src="./js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="./js/responsive.bootstrap.min.js"></script>
<script type="text/javascript" src="../js/sweetalert.min.js"></script>
<script src="plugins/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/js/all.min.js"></script>

</body>

</html>
<script type="text/javascript">
$(function () {
  $("#datepicker1").datepicker({
        autoclose: true,
        todayHighlight: true,
        format:"dd/mm/yy"
  }).datepicker('update', new Date());

  $("#datepicker2").datepicker({
    autoclose: true,
    todayHighlight: true,
    format:"dd/mm/yy"
  }).datepicker('update', new Date());



});

</script>
<script type="text/javascript">
$(document).ready(function() {
  var table = $('#example').DataTable( {
      responsive: true
      } );

  new $.fn.dataTable.FixedHeader( table );
} );
</script>
<script type="text/javascript">
   $(document).ready(function () {
       if($("#elm1").length > 0 ){
           tinymce.init({
               selector: "textarea#elm1",
               theme: "modern",
               height:300,
               plugins: [
                   "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                   "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                   "save table contextmenu directionality emoticons template paste textcolor"
               ],
               document_base_url : "https://megarealestate.pk/",
               toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",
               style_formats: [
                   {title: 'Bold text', inline: 'b'},
                   {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                   {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                   {title: 'Example 1', inline: 'span', classes: 'example1'},
                   {title: 'Example 2', inline: 'span', classes: 'example2'},
                   {title: 'Table styles'},
                   {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
               ]
           });
       }
       if($("#elm2").length > 0 ){
           tinymce.init({
               selector: "textarea#elm2",
               theme: "modern",
               height:300,
               plugins: [
                   "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                   "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                   "save table contextmenu directionality emoticons template paste textcolor"
               ],
               document_base_url : "https://megarealestate.pk/",
               toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",
               style_formats: [
                   {title: 'Bold text', inline: 'b'},
                   {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                   {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                   {title: 'Example 1', inline: 'span', classes: 'example1'},
                   {title: 'Example 2', inline: 'span', classes: 'example2'},
                   {title: 'Table styles'},
                   {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
               ]
           });
       }
       if($("#elm3").length > 0 ){
           tinymce.init({
               selector: "textarea#elm3",
               theme: "modern",
               height:300,
               plugins: [
                   "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                   "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                   "save table contextmenu directionality emoticons template paste textcolor"
               ],
               document_base_url : "https://megarealestate.pk/",
               toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",
               style_formats: [
                   {title: 'Bold text', inline: 'b'},
                   {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                   {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                   {title: 'Example 1', inline: 'span', classes: 'example1'},
                   {title: 'Example 2', inline: 'span', classes: 'example2'},
                   {title: 'Table styles'},
                   {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
               ]
           });
       }
       if($("#elm4").length > 0 ){
           tinymce.init({
               selector: "textarea#elm4",
               theme: "modern",
               document_base_url : "https://megarealestate.pk/",
               height:300,
               plugins: [
                   "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                   "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                   "save table contextmenu directionality emoticons template paste textcolor"
               ],
               toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",
               style_formats: [
                   {title: 'Bold text', inline: 'b'},
                   {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                   {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                   {title: 'Example 1', inline: 'span', classes: 'example1'},
                   {title: 'Example 2', inline: 'span', classes: 'example2'},
                   {title: 'Table styles'},
                   {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
               ]
           });
       }
   });
</script>
<script>
           if($("#desc").length > 0 ){
           tinymce.init({
               selector: "textarea#desc",
               theme: "modern",
               document_base_url : "https://megarealestate.pk/",
               height:300,
               plugins: [
                   "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                   "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                   "save table contextmenu directionality emoticons template paste textcolor"
               ],
               toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",
               style_formats: [
                   {title: 'Bold text', inline: 'b'},
                   {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                   {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                   {title: 'Example 1', inline: 'span', classes: 'example1'},
                   {title: 'Example 2', inline: 'span', classes: 'example2'},
                   {title: 'Table styles'},
                   {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
               ]
           });
       }
</script>

</body>
</html>
