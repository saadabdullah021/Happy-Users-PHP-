<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$msg='';
if(isset($_POST['done'])){

  $facebook=$_POST['facebook'];
  $twitter=$_POST['twitter'];
  $linkedin=$_POST['linkedin'];
  $pinterest=$_POST['pinterest'];
  $instagram=$_POST['instagram'];
  
  $upload=mysqli_query($db,"update social_links set facebook='$facebook',twitter='$twitter',linkedin='$linkedin',pinterest='$pinterest',instagram='$instagram' where id='1'");
  
    // header('location:social_links.php');
    $msg="<div class='alert alert-success '>Links Updated Successfully</div><br>";
}

$query=mysqli_query($db,"select * from social_links where id='1'");
$row=mysqli_fetch_array($query);

?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12 text-center">


<br>
<h1>Change social Links</h1>
<br>
<?php echo $msg; ?>
<form enctype="multipart/form-data" method="post">

<div class="row">
<div class="col-md-6">
  <div class="form-group">

  <label for="">Facebook Link</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fab fa-facebook"></i>
</div>
<input type="text" class="form-control" name="facebook" placeholder="Enter Facebook Link" value="<?=$row['facebook']?>" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Twitter Link</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fab fa-twitter "></i>
</div>
<input type="text" class="form-control" name="twitter" placeholder="Enter Twitter Link" value="<?=$row['twitter']?>" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">LinkedIn Link</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fab fa-linkedin"></i>
</div>
<input type="text" class="form-control" name="linkedin" placeholder="Enter LinkedIn Link" value="<?=$row['linkedin']?>" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Pinterest Link</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fab fa-pinterest "></i>
</div>
<input type="text" class="form-control" name="pinterest" placeholder="Enter Pinterest Link" value="<?=$row['pinterest']?>" required>
</div>
</div>
</div>

<div class="col-md-3">
</div>
<div class="col-md-6">
  <br>
  <div class="form-group">

  <label for="">Instagram Link</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fab fa-instagram"></i>
</div>
<input type="text" class="form-control" name="instagram" placeholder="Enter Instagram Link" value="<?=$row['instagram']?>" required>
</div>
</div>
</div>


</div>
<br>
<input type="submit" name="done" value="Update Links"  class="btn btn-info" >

</div>
</div>
</div>
<br>  
</form>
<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
