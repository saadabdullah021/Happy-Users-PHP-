<?php
include 'header.php';
include 'menu.php';
include 'config.php';
$msg='';
if (isset($_POST['submit'])) {
  foreach($_FILES["upload_imgs"]["tmp_name"] as $key=>$tmp_name) {
  $file_name=$_FILES["upload_imgs"]["name"][$key];
  $file_tmp=$_FILES["upload_imgs"]["tmp_name"][$key];
  $extension=array("jpeg","jpg","png","gif");
  $ext=pathinfo($file_name,PATHINFO_EXTENSION);
  if(in_array($ext,$extension)) {
  $upload=mysqli_query($db,"insert into library(name)values('$file_name')");
  if($upload){
  move_uploaded_file($file_tmp=$_FILES["upload_imgs"]["tmp_name"][$key],"../img/library/".$file_name);
  $check=1;
  }
  else {
  $check=0;
  }
  if($check==1){
  $ok= "Project Added Successfully and sent for approval. An admin will get in touch with you soon via email.";
  header('location:library.php');
  }
  else if($check==0){
  $msg= "Something Went Wrong, Please Try Again Later";}
  }
  }
}
 ?>


<section id="contents">
<?php include 'nav.php'; ?>

<br>
<br>
<div class="container-fluid" style="color:#000">

<div class="col-md-12">

<div class="panel panel-default">
<div class="panel-heading">
  <h2>Library Images</h2>
</div>
<div class="panel-body">

  <div class="row">
    <br><br>
    <div class="container">

    <form enctype="multipart/form-data" method="post" onsubmit="return validation()" id="contact_form">


    <!-- Form Name -->
      <br>




    <div class="col-md-12">
    <label for="upload_imgs" class="btn btn-primary" >Select Images +</label>
    <input class="show-for-sr hidden" type="file" required id="upload_imgs" name="upload_imgs[]" multiple/>
    <span class=" alert-info btn-sm"><medium> <i class="fa fa-exclamation-triangle"></i> Press CTRL to select multiple images at once</medium></span>
    <br> <span style="padding: 15px" class="error" id="imgs"> Please Attach atleast one image </span>
    <br>
    <div class="grid-x grid-padding-x" style="color:black">
    <div class="small-10 small-offset-1 medium-8 medium-offset-2 cell">
    <p>
    <div class="quote-imgs-thumbs quote-imgs-thumbs--hidden" id="img_preview" aria-live="polite"></div>
    </p>

    </div>
    </div>
    <div class="row">
    <div class="col-md-12">
    <div class="form-group">
    <button id="submit" type="submit" name="submit" class="btn btn-primary" >Submit <span class=""></span></button>
    </div>
    </div>
    </div>
    </div>

    <!-- Button -->

    </div>

    </fieldset>
    </form>
  </div>
</div>

</div>
</div>
<div class="col-md-12" style="color:black">
<div class="panel panel-default">
<div class="panel-heading">
  <h2>Library Images</h2>
</div>
<div class="panel-body">



<?php
$q=mysqli_query($db,'select * from library order by id desc');
while($row=mysqli_fetch_array($q)) {
  // code...
  ?>


<div class="col-md-3">
  <br>


  <div id="myModal<?php echo $row['id']; ?>" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Copy Image Address</h4>
        </div>
        <div class="modal-body">

<p>
  https://megarealestate.pk/img/library/<?php echo $row['name']; ?>
</p>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>
<div class="center" style="background:url('../img/library/<?php echo $row['name'] ?>');height:200px; width:200px;background-size:cover">

</div>
<br>
<div class="text-center">

<button class="btn btn-success btn-sm"  data-toggle="modal" data-target="#myModal<?php echo $row['id']; ?>"> <i class="fa fa-copy"></i> </button>
<a href="delete.php?delete_img=<?php echo $row['id'] ?>">
  <button class="btn btn-danger btn-sm" > <i class="fa fa-trash"></i> </button>
</a>
</div>

</div>
<?php
}
?>
<div class="clearfix">

</div>

</div>

</div>
</div>



    </div>
    </div><!-- /.container -->



  </div>
</div>

</section>


<?php
include 'footer.php';
 ?>
    <script type="text/javascript">
    var imgUpload = document.getElementById('upload_imgs')
    , imgPreview = document.getElementById('img_preview')
    , imgUploadForm = document.getElementById('contact-form')
    , totalFiles
    , previewTitle
    , previewTitleText
    , img;

    imgUpload.addEventListener('change', previewImgs, false);


    function previewImgs(event) {
    totalFiles = imgUpload.files.length;
    if(upload_imgs=="")
    {
    return false;
    }
    if(!!totalFiles) {
    imgPreview.classList.remove('quote-imgs-thumbs--hidden');
    previewTitle = document.createElement('p');
    previewTitle.style.fontWeight = 'bold';
    previewTitleText = document.createTextNode(totalFiles + ' Total Images Selected');
    previewTitle.appendChild(previewTitleText);
    imgPreview.appendChild(previewTitle);
    }

    for(var i = 0; i < totalFiles; i++) {
    img = document.createElement('img');
    img.src = URL.createObjectURL(event.target.files[i]);
    img.classList.add('img-preview-thumb');
    imgPreview.appendChild(img);
    }
    }

    </script>
