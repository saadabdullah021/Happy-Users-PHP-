<?php include('header.php') ?>
<?php include('config.php'); ?>
<div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">

<?php if (isset($_GET['edit'])) {
  $eid=$_GET['edit'];
  $query= mysqli_query($db,"select * from associations where id='$eid'");
  $row=mysqli_fetch_array($query);
}
$msg='';

if(isset($_POST['update'])){
//   $date=date('d M Y');
  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  
  // $upload=mysqli_query($db,"insert into posts(post_title,post_content,post_image,date) values('$name','$content','$file_name','$date')");
$update=mysqli_query($db,"update associations set image='$file_name' where id='$eid'");
if ($update && move_uploaded_file($file_tmp,"../uploads/".$file_name)) {
  header('location:associations.php');
}

}


?>


<br>
<h1>Change Logo</h1>
<br>
<?php echo $msg; ?>


<br>    
<form enctype="multipart/form-data" method="post">

<div class="row">

<div class="col-md-12">

  <div class="form-group">


  <div class="input-group">

<img style="width: 100%;" src="../uploads/<?php  echo $row['image']; ?>">

</div>
</div>
</div>

  <div class="col-md-6">
  <div class="form-group">

    <br>
    <br>
  <label for="">Slider Image</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-camera"></i>
  </div>
  <input type="file" class="form-control" name="pic"  value="" required>
  </div>
  </div>
  <div class="form-group">
    <input type="submit" name="update" value="Update Image" class="btn btn-info">
  </div>
</div>
</div>
</div>
<br>


</form>
</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
$(function() {
    $('#elm1').ckeditor({
        toolbar: 'Full',
        enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
});
</script>