<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$q=mysqli_query($db,"select * from admin where id='$user'");
$v=mysqli_fetch_array($q);
if (isset($_POST['submit'])){
  $password=$_POST['name'];

  
$query=mysqli_query($db,"update admin set password='$password'");
if ($query) {
  header('location:profile.php');
}
}
if (isset($_POST['save'])) {
  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  $myquery=mysqli_query($db,"update admin set image='$file_name' where id='$user' ");
if($myquery){
  move_uploaded_file($file_tmp,"../upload/".$file_name);
header('location:profile.php');
}
}


 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <br>
  <div class="container" style="color:black">
<br>


<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-xs">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="modal-title ehead">Change Profile Picture</h3>
      </div>
      <div class="modal-body">
        <form method="post" enctype="multipart/form-data">
        <img src="../upload/<?php if($v['image']!=""){ echo $v['image']; } else {echo "person-icon-8.png"; } ?>"  id="blah" style="height:200px;width:200px;border-radius:50%;border:3px solid white;display:block;margin:0 auto;
        " >
        <br>
        <input type="file" class="hidden" name="pic" value="" onchange="readURL(this);" id="pic">
        <label for="pic" class="btn btn-info" style="width:150px;display:block;margin:0 auto">Choose Picture</label>
        <br>
        <input type="submit" name="save" class="btn google" style="width:150px;display:block;margin:0 auto" value="Update">
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



<div class="row" style="color:#000">

    <div class="col-md-10">   
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <div class="row">
          <div class="col-md-6">
            <h3>Edit Your Profile</h3>
         </div>
          <div class="col-md-6 text-right">
        <div class="row">
          <p style="padding-right:12px;padding-top:23px;vertical-align: middle">
            <a href="edit-profile.php">Edit Profile</a> |
          <a href="edit-password.php" title="">Edit Password</a> |
        <a href="logout.php">Logout <i class="fa fa-sign-out-alt"></i> </a>
          </p>
          </div>
        </div>
        </div>

      </div>

      <div class="panel-body">

<div class="col-md-4">
    <?php if ($v['image']!=""){ ?>

  <img src="../upload/<?php echo $v['image'] ?>" style="height:200px;width:200px;border-radius:50%;border:3px solid white;display:block;margin:0 auto;
  " alt="">
  <?php
  }else{
  ?>
  <img src="../uploads/person-icon-8.png" style="height:200px;width:200px;border-radius:50%;border:3px solid white;display:block;margin:0 auto;
  " alt="">


  <?php
  }

  ?>
</div>
<div class="col-md-8">
<h1><?php echo $v['name'] ?></h1>
<p>
<span style="cursor:pointer" data-toggle="modal" data-target="#myModal"> <i class="fa fa-edit"></i> Change Profile Picture</span>
</p>
<p>

<a href="logout.php">Logout <i class="fa fa-sign-out-alt"></i> </a>
</p>
</div>



<h2 align=center></h2>
<div class="col-md-6 col-md-offset-3">
  <form class=""  method="post">

<div class="form-group">
<p align=center>Password
<input type="text" name="name" class="form-control" required placeholder="Enter New Password" value="<?php echo $v['password'] ?>">
</p>
</div>
  



    <input type="submit" name="submit" value="Update" class="btn blue pull-left" style="width:200px;">    



<a href="profile.php">
<button type="button" name="btn" class="btn google upd pull-right" style="width:200px;">Go Back</button>
</a>
<br>
</form>

</div>

</div>
</div>
</div>
</div>

</div>
  </div>
</div>
<?php include('footer.php') ?>

<script type="text/javascript">
function readURL(input) {
     if (input.files && input.files[0]) {
         var reader = new FileReader();

         reader.onload = function (e) {
             $('#blah')
                 .attr('src', e.target.result);
         };

         reader.readAsDataURL(input.files[0]);
     }
 }
 $('#formid').on('keyup keypress', function(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) {
    e.preventDefault();
    return false;
  }
});
$('#myform').on('keyup keypress', function(e) {
 var keyCode = e.keyCode || e.which;
 if (keyCode === 13) {
   e.preventDefault();
   return false;
 }
});

</script>
