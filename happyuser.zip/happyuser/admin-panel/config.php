 <?php

if(!isset($_SESSION['userid'])){
  header('location:index.php');
  die();
}
$admin=$_SESSION['userid'];
$user=$_SESSION['userid'];

 ?>
