
<?php 

include('config.php');

 ?>


<aside class="side-nav" id="show-side-navigation1">
  <i class="fa fa-bars close-aside hidden-sm hidden-md hidden-lg" data-close="show-side-navigation1"></i>
  <div class="heading">
    <div class="info text-center">
      <h1><a href="home.php">
        <img src="../assets/img/white-logo.png"  alt="">
        </a>
      </h1>
    </div>
  </div>
  <div class="clearfix">

  </div>

 
  <ul class="only-one">
    <li> <i class="fa fa-home fa-fw"></i> <a href="home.php">Dashboard</a> </li>
    <li> <i class="fa fa-bars fa-fw"></i> <a href="categories.php">Manage Categories</a> </li>
    <li> <i class="fa fa-newspaper fa-fw"></i> <a href="blogs.php">Manage Blogs</a> </li>
    <li> <i class="fas fa-link fa-fw"></i> <a href="social_links.php">Manage Social Links</a> </li>
    <li> <i class="fa fa-id-card fa-fw"></i> <a href="admin-accounts.php">Manage Admins</a> </li>
    <li> <i class="fa fa-sign-out-alt"></i> <a href="logout.php">Logout</a> </li> 
 </ul>
       


</aside>




