<?php include('header.php') ?>
<?php include('config.php');
$msg="";
// if (isset($_GET['delete'])) {
//   $did=$_GET['delete'];
// $query=mysqli_query($db,"delete from admin where id='$did'");
// if($query){
//   $msg="<div class='alert alert-success '>Admin Added Successfully</div><br>";
// }
// else{
//   $msg="<div class='alert alert-danger'>Error Deleting Admin</div><br>";
// }
// }
 ?>
 <div id="contents">
   <?php include('menu.php') ?>
   <?php include('nav.php') ?>
  <div class="container-fluid">

<div class="col-md-12">

<br>
<h1>Manage Admins</h1>
<br>
<?php echo $msg; ?>
<br>
<a href="create-admin.php">
<button class="btn btn-warning">Add Admin</button>
</a>
<br>
<br>

<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Image</th>
  <th>Name </th>
  <th>Email</th>
  <!-- <th>Delete</th> -->
</tr>
</thead>
<tbody>

  <?php
  $results=mysqli_query($db,"SELECT * FROM admin");
$a=1;
  while ($data = mysqli_fetch_array($results)  )
{
    ?>
<tr>
<td><?= $a ?></td>
<td><img src="../upload/<?= $data['image'] ?>" style="display:block;margin:auto" height="50" width="50"></td>
<td><?= $data['name'] ?></td>
<!-- <td><?= $data['content'] ?></td> -->
<td><?= $data['email'] ?></td>

<!-- <td><button class="btn btn-danger edit" onclick="deletePost(<?= $data['id'] ?>) "  > <i class="fa fa-trash"></i> </td> -->
</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>
</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
  function deletePost(v){
    location.href='admin-accounts.php?delete='+v;
  }
  function edit(v){
    location.href='edit-blog.php?edit='+v;
  }
</script>
