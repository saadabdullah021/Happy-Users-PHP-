<?php include('header.php') ?>
<?php include('menu.php') ?>
<?php include 'config.php'; ?>
<?php
  $a1=mysqli_query($db,"select * from admin");
  $c1=mysqli_num_rows($a1);
   
  $a3=mysqli_query($db,"select * from blogs");
  $d=mysqli_num_rows($a3);

 ?>
    <section id="contents">
      <?php include('nav.php') ?>



      <div class="welcome">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="content">
                <h2>Welcome to HappyUser</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
        <section class='statis text-center'>
          <div class="container-fluid">
            <div class="row">
                
                    <div class="col-md-3">
                <div class="box bg-warning" style="color:#000">
                  <i class="fa fa-quote-right"></i>
                  <h3><?php  echo $c1; ?></h3>
                  <p class="lead">Total Admins</p>
                </div>
              </div>
            

              
              
              
               <div class="col-md-3">
                <div class="box danger">
                  <i class="fa fa-quote-right"></i>
                  <h3><?php echo $d; ?></h3>
                  <p class="lead">Total Blogs</p>
                </div>
              </div> 

              
               
          
              

<div class="clearfix">

</div>
            </div>
          </div>
        </section>
<?php include('footer.php') ?>
