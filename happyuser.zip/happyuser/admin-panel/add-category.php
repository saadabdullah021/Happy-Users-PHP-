<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$msg='';
if(isset($_POST['done'])){
  $name=$_POST['title'];
  $date=date('d M Y');
  
  $upload=mysqli_query($db,"insert into category(name,date) values('$name','$date')");
  
    header('location:categories.php');
  

}

 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">


<br>
<h1>ADD Category</h1>
<br>
<?php echo $msg; ?>
<form enctype="multipart/form-data" method="post">

<div class="row">
<div class="col-md-6">
  <div class="form-group">

  <label for="">Category Name</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="title" placeholder="Enter Category Name" value="" required>
</div>
</div>
</div>


</div>
<br>
<input type="submit" name="done" value="Upload Category"  class="btn btn-info" >

</div>
</div>
</div>
<br>  
</form>
<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
