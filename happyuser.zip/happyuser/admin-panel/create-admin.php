<?php include('header.php') ?>
<?php include('config.php') ?>
<?php
$msg='';
if(isset($_POST['done'])){
  
  $name=mysqli_real_escape_string($db,$_POST['title']);
  $email=mysqli_real_escape_string($db,$_POST['email']);
  $pass=mysqli_real_escape_string($db,$_POST['pass']);
  
  $file_name=$_FILES['pic']['name'];
  $file_tmp=$_FILES['pic']['tmp_name'];
  $upload=mysqli_query($db,"insert into admin(name,email,image,password,type) values('$name','$email','$file_name','$pass','1')");
  
  if(move_uploaded_file($file_tmp,"../upload/".$file_name)){
    $msg="<br><br><div class='alert alert-success'>Admin Added successfully</div>"  ;
    
    header('location:admin-accounts.php');
  }

}

 ?>
 <div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">


<br>
<h1>ADD Admin</h1>
<br>
<?php echo $msg; ?>
<form enctype="multipart/form-data" method="post">

<div class="row">
<div class="col-md-6">
  <div class="form-group">

  <label for="">Name</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="title" placeholder="Enter Name" value="" required>
</div>
</div>
</div>


<div class="col-md-6">
  <div class="form-group">

  <label for="">Email</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="Email" class="form-control" name="email" placeholder="Enter Email" value="" required>
</div>
</div>
</div>

<div class="col-md-6">
  <div class="form-group">

  <label for="">Password</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="Password" class="form-control" name="pass" placeholder="Enter Email" value="" required>
</div>
</div>
</div>



<div class="col-md-6">
  <div class="form-group">

  <label for="">Image</label>
  <div class="input-group">
  <div class="input-group-addon icon">
  <i class="fa fa-camera"></i>
  </div>
  <input type="file" class="form-control" name="pic" value="" required>
  </div>
  </div>
</div>




</div>
<br>
<input type="submit" name="done" value="Add Admin"  class="btn btn-info" >

</div>
</div>
</div>
<br>  
</form>
<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
