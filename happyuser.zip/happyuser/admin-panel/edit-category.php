<?php include('header.php') ?>
<?php include('config.php'); ?>
<div id="contents">
  <?php include('menu.php') ?>
  <?php include('nav.php') ?>
  <div class="container-fluid">
<div class="col-md-12">

<?php if (isset($_GET['edit'])) {
  $eid=$_GET['edit'];
  $query= mysqli_query($db,"select * from category where id='$eid'");
  $row=mysqli_fetch_array($query);
}
$msg='';
if(isset($_POST['done'])){
  $name=$_POST['title'];

  
$upload=mysqli_query($db,"update category set name='$name' where id='$eid'");
if ($upload) {
  // code...
header('location:categories.php');
}

}


?>


<br>
<h1>Edit Category</h1>
<br>
<?php echo $msg; ?>

<form enctype="multipart/form-data" method="post">

<div class="row">
<div class="col-md-6">
  <div class="form-group">

  <label for="">Category Name</label>
  <div class="input-group">
<div class="input-group-addon icon">
<i class="fa fa-edit "></i>
</div>
<input type="text" class="form-control" name="title" placeholder="Category Name" value="<?php echo $row['name'] ?>" required>
</div>
</div>
</div>


</div>
<br>
<input type="submit" name="done" value="Update Name"  class="btn btn-info" >


</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
$(function() {
    $('#elm1').ckeditor({
        toolbar: 'Full',
        enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
});
</script>