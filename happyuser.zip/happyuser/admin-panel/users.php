<?php include('header.php') ?>
<?php include('menu.php') ?>
<?php include 'config.php';
$msg="";
if (isset($_GET['make-true'])) {
  // code...
$id= $_GET['make-true'];
$q=mysqli_query($db,"update users set type='2' where userid='$id'");
if($q){
$msg="User Marked As Realtor Successfully";
}
}
if (isset($_GET['make-false'])) {
  $id= $_GET['make-false'];
$q=mysqli_query($db,"update users set type='0' where userid='$id'");
if($q){
  $msg="User Marked As Normal User Successfully";
}
}
?>

    <section id="contents">
      <?php include('nav.php') ?>

<div class="col-md-12">


<br>
<h1> Manage Users</h1>
<br>
<br>
<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Name</th>
  <th>Email</th>
  <th>Password</th>
  <th>Phone</th>
  <th>Pic</th>
  <th>Mark Realtor</th>
  <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
  $results=mysqli_query($db,"SELECT * FROM users where (type='0' or type='2') order by userid desc");
$a=1;
  while ($data = mysqli_fetch_array($results))
{
    ?>
<tr>
<td><?= $a ?></td>
<td><?= $data['name'] ?></td>
<td><?= $data['email'] ?></td>
<td><?= $data['password'] ?></td>
<td><?= $data['phone'] ?></td>
<td><img src="<?php if($data['gpic']==1){?>../img/<?= $data['pic'];} else echo $data['pic']; ?>" width="50"></td>
<td>
  <?php if ($data['type']==0){
    // code...
    ?>
    <a href="users.php?make-true=<?php echo $data['userid']; ?>" >
    <button class="btn btn-success"> <i class="fa fa-check"></i> Make Realtor</button>
  </a>

    <?php
    }else if($data['type']==2){ ?>
      <a href="users.php?make-false=<?php echo $data['userid']; ?>" >
      <button class="btn btn-success"> <i class="fa fa-times"></i> Remove Realtor</button>
    </a>
    <?php
  } ?>
</td>
<td>
  <a href="delete.php?del_user=<?php echo $data['userid']; ?>" onclick="return confirm('Are you sure you want to delete?')">
  <button class="btn btn-danger"> <i class="fa fa-trash"></i> </button>
</a>
</td>


</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>


</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
