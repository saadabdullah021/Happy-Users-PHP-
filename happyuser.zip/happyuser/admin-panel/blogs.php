<?php include('header.php') ?>
<?php include('config.php');
$msg="";
if (isset($_GET['delete'])) {
  $did=$_GET['delete'];
$query=mysqli_query($db,"delete from blogs where id='$did'");
if($query){
  $msg="<div class='alert alert-success '>Blog Deleted Successfully</div><br>";
}
else{
  $msg="<div class='alert alert-danger'>Error Deleting Blog</div><br>";
}
}
 ?>
 <div id="contents">
   <?php include('menu.php') ?>
   <?php include('nav.php') ?>
  <div class="container-fluid">

<div class="col-md-12">

<br>
<h1>Manage Blog</h1>
<br>
<?php echo $msg; ?>
<br>
<a href="add-blog.php">
<button class="btn btn-warning">Add Blog</button>
</a>
<br>
<br>

<table id="example" class="table  table-bordered nowrap" style="width:100%">
<thead>
<tr>
  <th>Sr.</th>
  <th>Blog Image</th>
  <th>Category </th>
  <th>Blog Title </th>
  <th>Date</th>
  <th>Edit</th>
  <!-- <th>Delete</th> -->
</tr>
</thead>
<tbody>

  <?php
  $results=mysqli_query($db,"SELECT * FROM blogs");
$a=1;
  while ($data = mysqli_fetch_array($results)  )
{
    ?>
<tr>
<td><?= $a ?></td>
<td><img src="../upload/<?= $data['image'] ?>" style="display:block;margin:auto" height="50" width="50"></td>
<td><?php 
  $cid=$data['category']; 
  $qc=mysqli_query($db,"select * from category where id='$cid'");
  $rc=mysqli_fetch_array($qc);
  echo $rc['name'];
   ?></td>
<td><?= $data['title'] ?></td>
<td><?= $data['date'] ?></td>
<td>
  <button class="btn btn-info edit"  onclick="edit(<?= $data['id'] ?>)" > <i class="fa fa-edit"></i>
</td>
<!-- <td><button class="btn btn-danger edit" onclick="deletePost(<?= $data['id'] ?>) "  > <i class="fa fa-trash"></i> </td> -->
</tr>
<?php
$a++;
}
?>
</tbody>
</table>


</div>
</div>
</div>

<!--
    <button type="button" class="slide-toggle">Slide Toggle</button>
  -->


<?php include('footer.php') ?>
<script type="text/javascript">
  function deletePost(v){
    location.href='blogs.php?delete='+v;
  }
  function edit(v){
    location.href='edit-blog.php?edit='+v;
  }
</script>
